function generateFrontPage() {
  const name = document.getElementById("studentName").value;
  const usn = document.getElementById("usn").value;
  const section = document.getElementById("section").value;
  const assignmentNo = document.getElementById("assignmentNo").value;
  const topic = document.getElementById("topic").value;
  const subject = document.getElementById("subject").value;
  const teacherName = document.getElementById("teacherName").value;
  const topicType = document.getElementById("topicType").value;

  const frontHTML = `
    <div id="printWrapper" style="width: 100%; height: 100vh; display: flex; justify-content: center; align-items: center;">
      <div style="
        width: 80%;
        border: 2px solid black;
        padding: 40px 30px;
        font-family: 'Times New Roman', Times, serif;
        box-sizing: border-box;
        text-align: center;
      ">
        <div class="university-details" style="line-height: 1.4;">
          <h3 style="margin: 0; font-weight: normal;">Srishyla Educational Trust ®</h3>
          <h1 style="font-size: 32px; margin: 5px 0; font-weight: 800;">GM UNIVERSITY</h1>
          <p style="margin: 0; font-size: 14px;">(Established under the Karnataka State Act No. 19 of 2023)</p>
          <p style="margin: 0; font-size: 14px;">Post Box No. 4, Davanagere - 577006</p>
        </div>

        <div style="margin: 20px 0;">
          <img src="https://i.postimg.cc/KvhJ6pCj/gm-logo.jpg" alt="GM University Logo" style="max-width: 100px;" />
        </div>

        <h3 style="margin: 15px 0 0;">${subject}</h3>
        <h3 style="margin: 5px 0;">Assignment - ${assignmentNo}</h3>
        <p style="margin: 10px 0;"><strong>${topicType}:</strong> ${topic.toUpperCase()}</p>
        <p style="margin: 10px 0;"><strong>Section -</strong> "${section}"</p>

        <div style="display: flex; justify-content: space-between; margin-top: 40px; text-align: left; font-size: 14px;">
          <div>
            <strong>Submitted By:</strong><br>
            ${name}<br>
            ${usn}
          </div>
          <div style="text-align: right;">
            <strong>Submitted To:</strong><br>
            ${teacherName}<br>
            Department of ISE<br>
            GM University<br>
            Davanagere
          </div>
        </div>
      </div>
    </div>
  `;

  const frontPage = document.getElementById("frontPage");
  frontPage.innerHTML = frontHTML;
  frontPage.style.display = "block";
  document.getElementById("downloadButton").style.display = "inline-block";
}

function downloadPdf() {
  const element = document.getElementById("frontPage");

  html2canvas(element, {
    useCORS: true,
    scale: 3,
    windowWidth: element.scrollWidth,
    windowHeight: element.scrollHeight
  }).then((canvas) => {
    const imgData = canvas.toDataURL("image/png");
    const pdf = new jspdf.jsPDF("p", "mm", "a4");

    const pageWidth = pdf.internal.pageSize.getWidth();
    const pageHeight = pdf.internal.pageSize.getHeight();
    const imgWidth = pageWidth;
    const imgHeight = (canvas.height * imgWidth) / canvas.width;

    const yPosition = (pageHeight - imgHeight) / 2;

    pdf.addImage(imgData, "PNG", 0, yPosition, imgWidth, imgHeight);
    pdf.save("assignment_front_page.pdf");
  });
}
